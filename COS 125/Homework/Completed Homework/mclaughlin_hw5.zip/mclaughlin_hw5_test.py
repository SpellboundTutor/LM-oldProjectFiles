import mclaughlin_hw5

# test1 = mclaughlin_hw5.EleAdd([1,3,5,7],[2,4,6,8])
# print(f"EleAdd test with equal values in List A and List B:{test1}")

# test1 = mclaughlin_hw5.EleAdd([1,3,5,7,9],[2,4,6,8])
# print(f"EleAdd test with greater values in List A than List B:{test1}")

# test1 = mclaughlin_hw5.EleAdd([1,3,5,7],[2,4,6,8,10])
# print(f"EleAdd test with fewer values in List A than List B:{test1}")

# test1 = mclaughlin_hw5.EleAdd([],[])
# print(f"EleAdd test with no values in List A nor List B:{test1}")

# test2 = mclaughlin_hw5.FindSL("This is a sentence with only one predictable punctuation point.")
# print(f"Test 2: FindSL results: {test2}")

# test2 = mclaughlin_hw5.FindSL("Th,s is a sen.ence w!th at least one unpredi?table punctuat!on po!nt")
# print(f"Test 2: FindSL results: {test2}")

# test2 = mclaughlin_hw5.FindSL("This is a sentence with only no predictable punctuation points")
# print(f"Test 2: FindSL results: {test2}")

# test2 = mclaughlin_hw5.FindSL("")
# print(f"Test 2: FindSL results: {test2}")

# test3 = mclaughlin_hw5.FindMedian([2,4,6,8])
# print(f"Test 3: FindMedian results: {test3}")

# test3 = mclaughlin_hw5.FindMedian([1,3,5,7,9])
# print(f"Test 3: FindMedian results: {test3}")

# test3 = mclaughlin_hw5.FindMedian([])
# print(f"Test 3: FindMedian results: {test3}")

# test4 = mclaughlin_hw5.Create2DList(3, 5, "fish")
# print(f"Test 4: Create2DList result:{test4}")

# test4 = mclaughlin_hw5.Create2DList(0, 5, "fish")
# print(f"Test 4: Create2DList result:{test4}")

# test4 = mclaughlin_hw5.Create2DList(3, 0, "fish")
# print(f"Test 4: Create2DList result:{test4}")

# test5 = mclaughlin_hw5.UniqueRandList(1, 10, 5)
# print(f"Test 5: UniqueRandList results: {test5}")

# test5 = mclaughlin_hw5.UniqueRandList(7, 10, 5)
# print(f"Test 5: UniqueRandList results: {test5}")

# test5 = mclaughlin_hw5.UniqueRandList(10, 1, 5)
# print(f"Test 5: UniqueRandList results: {test5}")

# test5 = mclaughlin_hw5.UniqueRandList(6, 10, 5)
# print(f"Test 5: UniqueRandList results: {test5}")